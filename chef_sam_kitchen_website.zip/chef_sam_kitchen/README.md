# Chef Sam's Kitchen Website

## Overview
A professional website for Chef Sam, a freelance and private chef based in Watamu, Kilifi County, Kenya. The website showcases Chef Sam's culinary expertise, menu offerings, and provides an easy way for customers to make reservations.

## Features
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices
- **Real Content**: Uses actual images and content from Chef Sam's social media accounts
- **Interactive Elements**: Smooth scrolling navigation, image galleries with lightbox, hover effects
- **Reservation System**: Contact form that sends WhatsApp messages directly to Chef Sam
- **Social Media Integration**: Links to Facebook, Instagram, and TikTok accounts
- **Professional Gallery**: Showcases Chef Sam's actual food creations and kitchen work

## Sections
1. **Hero Section**: Welcome message with Chef Sam's signature image
2. **About Section**: Chef Sam's story and background with real profile photo
3. **Menu Section**: Featured dishes with actual food photos and pricing
4. **Gallery Section**: Collection of Chef Sam's real cooking and food photos
5. **Contact Section**: Contact information and reservation form

## Contact Information
- **Phone**: +254796347647
- **Email**: muthamasam83@gmail.com
- **Location**: Watamu, Kilifi County, Kenya
- **Social Media**:
  - Facebook: https://www.facebook.com/share/158J9Erv1fN/
  - Instagram: @Chefsam003
  - TikTok: @Chef.sam003

## Technical Details
- **Framework**: HTML5, CSS3, JavaScript
- **Fonts**: Playfair Display, Inter, Dancing Script
- **Icons**: Font Awesome
- **Features**: CSS Grid, Flexbox, CSS Animations, Form Validation
- **Responsive**: Mobile-first design with breakpoints at 768px and 480px

## Files Structure
```
chef_sam_kitchen/
├── index.html              # Main HTML file
├── styles.css              # CSS styling
├── script.js               # JavaScript functionality
├── images/
│   └── chef_sam_real/      # Real images from social media
│       ├── chef_sam_hero_image.jpeg
│       ├── chef_sam_profile_photo.jpeg
│       ├── chef_sam_food_1.jpeg
│       ├── chef_sam_food_2.jpeg
│       ├── chef_sam_food_3.jpeg
│       ├── chef_sam_food_4.jpeg
│       └── chef_sam_food_5.jpeg
└── README.md               # This file
```

## Reservation System
The website includes a reservation form that:
- Validates all required fields
- Checks for valid email format
- Ensures future date selection
- Sends reservation details via WhatsApp to Chef Sam's number
- Provides immediate feedback to users

## Browser Compatibility
- Chrome (recommended)
- Firefox
- Safari
- Edge
- Mobile browsers

## Maintenance
To update content:
1. Edit the HTML file for text changes
2. Replace images in the images/chef_sam_real/ folder
3. Update contact information in both HTML and JavaScript files
4. Test locally before deploying changes

## Created By
This website was created using Chef Sam's actual social media content and contact information to provide an authentic representation of his culinary business.

